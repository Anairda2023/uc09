--CREATE DATABASE FAMILIA;
USE FAMILIA;

-- CREATE TABLE PAI (
--     COD_PAI INT NOT NULL,
--     NOME_PAI VARCHAR(150) NOT NULL,
--     IDADE_PAI INT NOT NULL,
--     PRIMARY KEY(COD_PAI)
-- );
-- CREATE TABLE FILHO(
--     COD_FILHO INT NOT NULL,
--     COD_PAI INT NOT NULL,
--     NOME_FILHO VARCHAR(150) NOT NULL,
--     GENERO_FILHO CHAR NOT NULL,
--     PRIMARY KEY(COD_FILHO),
--     FOREIGN KEY(COD_PAI) REFERENCES PAI(COD_PAI)
-- );

-- USE FAMILIA;
-- SHOW TABLE PAI;
-- INSERT INTO PAI (COD_PAI, NOME_PAI, IDADE_PAI) 
-- VALUES 
-- (1, 'Daniel de Souza Leão Sobrinho', 62), (2, 'João Carlos da Silva', 38), (3, 'Fernando de Oliveira', 36), (4, 'Jairo de Oliveira Leão', 32);

INSERT INTO FILHO  (COD_FILHO, COD_PAI, NOME_FILHO, GENERO_FILHO)
VALUES (1,1 'Renata de Oliveira Leão', 'F'), (2, 1, 'Fernando de Oliveira Leão', 'M'), (3, 1, 'Roberta de Oliveira Leão', 'F'), (4,1, 'Jairo de Oliveira Leão', 'M'), (5, 2, 'Giovanna da Silva', 'F'),  (6, 3,'Lucas Ribeiro de Oliveira', 'M'), (7, 3, 'Helder Ribeiro Oliveira', 'M');


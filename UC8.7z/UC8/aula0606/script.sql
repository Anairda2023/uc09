-- USE locadoradb;

-- SELECT name AS FILME, description AS GÊNERO FROM movies, genres WHERE id_genres = genres.id;

-- SELECT name AS FILME, description AS GÊNERO FROM movies, genres WHERE id_genres = genres.id ORDER BY name;

-- SELECT name AS FILME, description AS GÊNERO FROM movies, genres WHERE id_genres = genres.id ORDER BY description;

--  SELECT name AS FILME, description AS GÊNERO, id_genres AS Índice FROM movies, genres WHERE id_genres = genres.id and id_genres>3 ORDER BY name;
-- use locadoradb;

-- USE locadoradb;
--  SELECT name AS FILME, description AS GÊNERO, id_genres AS Índice FROM movies, genres WHERE id_genres = genres.id and name like "C%" ORDER BY name;

--   SELECT name AS FILME, description AS GÊNERO, id_genres AS Índice FROM movies, genres WHERE id_genres = genres.id and name like "%The%" ORDER BY name;
USE locadoradb;
 SELECT name AS movies, description AS genres, id_genres AS Índice FROM movies, genres WHERE id_genres = genres.id and id=2 ORDER BY movies;


--7. SELECIONE O NOME DOS FILMES E A DESCRIÇÃO DOS SEUS GÊNEROS, ONDE O ID DO GÊNERO SEJA IGUAL A 2, ORDENADOS PELO NOME DO FILME
USE locadoradb;
-- SELECT * from genres
SELECT name,  description FROM movies, genres 
WHERE id_genres = genres.id AND id_genres=2 ORDER BY name; 
--8. SELECIONE O NOME DOS FILMES E A DESCRIÇÃO DOS SEUS GÊNEROS, ONDE A DESCRIÇÃO DO GÊNERO CONTÉM A PALAVRA 'COMÉDIA', ORDENADOS PELO ID DO FILME.
use locadoradb
SELECT name, description FROM movies, genres
WHERE id_genres = genres.id AND description LIKE "%comedy%" ORDER BY movies.id;
--9. ATUALIZE O NOME DE UM FILME ESPECÍFICO (POR EXEMPLO, ID = 5) PARA 'NOVO NOME'.
UPDATE movies SET name = 'As Branquelas' 
WHERE id = 8;
--10. ATUALIZE O ID_GENERO DE UM FILME ESPECÍFICO (POR EXEMPLO, ID = 3) PARA 2.
UPDATE movies SET id_genres = 2
WHERE ID = 3;
--11. ATUALIZE A DESCRIÇÃO DE UM GÊNERO ESPECÍFICO (POR EXEMPLO, ID = 1) PARA 'DRAMA'
UPDATE genres SET description = 'Drama' 
WHERE ID = 3;
--12. ATUALIZE O NOME DOS FILMES CUJO ID_GENERO É 4 PARA 'FILME ATUALIZADO'
UPDATE movies SET name = 'FILME ATUALIZADO' 
WHERE id_genres = 4;
--13. ATUALIZE O ID_GENERO DE TODOS OS FILMES CUJO NOME COMEÇA COM 'A' PARA 3.
UPDATE movies SET id_genres = 3
WHERE name LIKE 'The%';
--14. DELETE UM FILME ESPECÍFICO (POR EXEMPLO, ID = 10).
DELETE FROM movies WHERE id = 10;
--15. DELETE TODOS OS FILMES CUJO ID_GENERO SEJA 4.
DELETE FROM movies WHERE id_genres=4;
--16. DELETE TODOS OS GÊNEROS CUJO ID SEJA MAIOR QUE 5.
DELETE FROM genres WHERE id > 5;
--17. DELETE TODOS OS FILMES CUJO NOME COMEÇA COM A LETRA 'B'.
DELETE FROM movies WHERE name LIKE 'M%';
--18. DELETE TODOS OS FILMES CUJO ID_GENERO SEJA 2 E O NOME CONTÉM 'TESTE'.
DELETE FROM movies WHERE id_genres = 2 AND name LIKE '%THE%';
--19. DELETE A TABELA GÊNERO
DROP TABLE genres;
--20. DELETE A TABELA FILMES
DROP TABLE movies;
--21. DELETE A BASE DE DADOS
DROP DATABASE locadoradb;

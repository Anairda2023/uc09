const num1= 2;
const num2= 4;
const num3= 6;
if (num1 >num2 && num1 > num3){
    console.log(`O número maior é o ${num1}`)
}else if (num2 > num1 && num2>num3){
    console.log(`O número maior é o ${num2}`)

}else if (num3> num1 && num3 >num2){
    console.log(`O número maior é o ${num3}`)


}else if (num1== num2 && num1==num3){
    console.log("São iguais");
}else if(num2==num3){
    console.log("Os números são iguais")
}else if (n1==n3){
    
    console.log("Os números são iguais")
    
}



   


let idade= 2024-2000;
if (idade<=12){
    console.log("Você é uma criança!!!")

}else if ( idade <= 17) {
    console.log("Você é jovem!!!")
}else if (idade <=59){
    console.log("Você é adulta!!!")
}else if (idade >60){
        console.log("Você é idoso!!!")
}else{
    console.log("Entrada inválida")
}    


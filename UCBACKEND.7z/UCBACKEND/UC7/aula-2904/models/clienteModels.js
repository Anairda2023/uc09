class Cliente{
    constructor(name, telefone, email){
        
        this.name= name;
        this.telefone = telefone;
        this.email = email;
        

    }
}

module.exports = Cliente;
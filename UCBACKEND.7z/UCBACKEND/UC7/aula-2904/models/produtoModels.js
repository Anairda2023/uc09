class Produto{
    constructor(id, name, preco){
        this.id = id;
        this.name= name;
        this.preco = preco;
        

    }
}

module.exports = Produto;
let dia = "domingo";
if (dia=="segunda" || dia=="terça" || dia=="quarta" ||dia=="quinta" ||dia=="sexta"){
    console.log("Estudo")
}else if (dia=="sabado" || dia=="domingo"){
    console.log("Fim de semana")
}else{
    console.log("Valor inválido")
}    


    
